# Transformation Matrices - sh_order_bot_for_ros

Homogeneous transformation matrices between consecutive frames.
Convention: URDF RPY (XYZ extrinsic / ZYX intrinsic).

## Notation

### Frames

| Index | Link |
|-------|------|
| $L_{0}$ | base_link |
| $L_{1}$ | left_wheel |
| $L_{2}$ | right_wheel |

### Joint Variables

| Variable | Joint | Type | From | To |
|----------|-------|------|------|----|
| $q_{1}$ | Revolute_5 | continuous (rad) | $L_{0}$ | $L_{1}$ |
| $q_{2}$ | Revolute_6 | continuous (rad) | $L_{0}$ | $L_{2}$ |

Shorthand: $c_i = \cos(q_i)$, $s_i = \sin(q_i)$

### Kinematic Tree

```
L0: base_link
  |-- [continuous] Revolute_5 (q1)
  |   L1: left_wheel
  +-- [continuous] Revolute_6 (q2)
      L2: right_wheel
```

## Transforms

## Revolute_5

$L_{0}$ **base_link** -> $L_{1}$ **left_wheel** (continuous)
  Variable: $q_{1}$

- **origin xyz**: (0.098758, 0, 0.02475) m
- **origin rpy**: (-1.570796, 0, 1.570796) rad
- **axis**: (0, 0, 1)

### Local Transform

$T^{0}_{1}(q_{1}) = T_{fixed} \cdot R_{axis}(q_{1})$ where:

$$
T_{fixed} = \begin{bmatrix}
0 & 0 & -1 & 0.098758 \\
1 & 0 & 0 & 0 \\
0 & -1 & 0 & 0.02475 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

$$
R_{axis}(q_{1}) = \begin{bmatrix}
c_{1} & -s_{1} & 0 & 0 \\
s_{1} & c_{1} & 0 & 0 \\
0 & 0 & 1 & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## Revolute_6

$L_{0}$ **base_link** -> $L_{2}$ **right_wheel** (continuous)
  Variable: $q_{2}$

- **origin xyz**: (-0.098758, 0, 0.02475) m
- **origin rpy**: (-1.570796, 0, 1.570796) rad
- **axis**: (0, 0, 1)

### Local Transform

$T^{0}_{2}(q_{2}) = T_{fixed} \cdot R_{axis}(q_{2})$ where:

$$
T_{fixed} = \begin{bmatrix}
0 & 0 & -1 & -0.098758 \\
1 & 0 & 0 & 0 \\
0 & -1 & 0 & 0.02475 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

$$
R_{axis}(q_{2}) = \begin{bmatrix}
c_{2} & -s_{2} & 0 & 0 \\
s_{2} & c_{2} & 0 & 0 \\
0 & 0 & 1 & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## Global Transform Chains

Transform from root $L_0$ to any link, as product of local transforms along the kinematic chain.

