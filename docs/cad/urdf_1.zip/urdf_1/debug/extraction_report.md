# Extraction Report: sh_order_bot_for_ros v1

**Exported:** 2026-10-25T21:31:46.565321
**Exporter:** v3.1.1

## Summary

| Metric | Value |
|--------|-------|
| Occurrences | 3 |
| Subassemblies | 0 |
| Leaf components | 3 |
| Joints (total) | 3 |
| As-built joints | 2 |
| Regular joints | 1 |
| Max nesting depth | 0 |

## Assembly Hierarchy

```
[sh_order_bot_for_ros]  (design root)
  ├── base_link  (924.9g)
  ├── left_wheel  (52.7g)
  ├── right_wheel  (52.7g)
```

## Occurrences

### Depth 0

#### 🔧 COMPONENT: `base_link`

| Property | Value |
|----------|-------|
| Full path | `base_link:1` |
| Component name | base_link |
| Depth | 0 |
| Path segments | base_link |
| **Transforms** | |
| Global position (m) | (0.000000, 0.000000, 0.000000) |
| Global position (mm) | (0.00, 0.00, 0.00) |
| Local transform (m) | (0.000000, 0.000000, 0.000000) |
| Assembly context depth | 0 |
| transform2 (m) | (0.000000, 0.000000, 0.000000) |
| **Physical** | |
| Mass | 0.924900 kg (924.900 g) |
| Volume | 8.725476e-04 m³ |
| Density | 1060.0 kg/m³ |
| Surface area | 2.573703e-01 m² |
| Body count | 1 |
| CoM (component-local, m) | (0.000000, 0.001963, 0.093378) |
| CoM (global, m) | (0.000000, 0.001963, 0.093378) |
| CoM (global, mm) | (0.00, 1.96, 93.38) |
| **Inertia at origin (kg·m²)** | |
| Ixx, Iyy, Izz | 1.225114e-02, 1.225841e-02, 1.943558e-03 |
| Ixy, Ixz, Iyz | 2.725984e-08, 5.009013e-08, -2.474966e-04 |
| **Inertia at CoM (kg·m²)** | |
| Ixx, Iyy, Izz | 4.182968e-03, 4.193801e-03, 1.939995e-03 |
| Ixy, Ixz, Iyz | 2.749865e-08, 6.145221e-08, -7.799567e-05 |
| Bounding box (m) | 0.1737 × 0.1450 × 0.2042 |
| Bounding box (mm) | 173.73 × 145.00 × 204.24 |
| **Material & Appearance** | |
| Material | ABS_Plastic |
| Appearance | Paint_Metallic_Blue |
| Color (RGB 0-1) | (0.145, 0.671, 0.953) |
| Color (RGB 0-255) | (37, 171, 243) |

#### 🔧 COMPONENT: `left_wheel`

| Property | Value |
|----------|-------|
| Full path | `left_wheel:1` |
| Component name | left_wheel |
| Depth | 0 |
| Path segments | left_wheel |
| **Transforms** | |
| Global position (m) | (0.076000, -0.000000, 0.024750) |
| Global position (mm) | (76.00, -0.00, 24.75) |
| Local transform (m) | (0.076000, -0.000000, 0.024750) |
| Assembly context depth | 0 |
| transform2 (m) | (0.076000, -0.000000, 0.024750) |
| **Physical** | |
| Mass | 0.052668 kg (52.668 g) |
| Volume | 4.968665e-05 m³ |
| Density | 1060.0 kg/m³ |
| Surface area | 2.029151e-02 m² |
| Body count | 1 |
| CoM (component-local, m) | (0.014869, -0.000000, -0.000000) |
| CoM (global, m) | (0.090869, -0.000000, 0.024750) |
| CoM (global, mm) | (90.87, -0.00, 24.75) |
| **Inertia at origin (kg·m²)** | |
| Ixx, Iyy, Izz | 3.510455e-05, 3.143996e-05, 3.144021e-05 |
| Ixy, Ixz, Iyz | 1.674052e-10, 7.693060e-11, -1.396434e-10 |
| **Inertia at CoM (kg·m²)** | |
| Ixx, Iyy, Izz | 3.510455e-05, 1.979552e-05, 1.979577e-05 |
| Ixy, Ixz, Iyz | -1.669447e-11, -4.693486e-11, -1.396415e-10 |
| Bounding box (m) | 0.0260 × 0.0670 × 0.0670 |
| Bounding box (mm) | 26.00 × 67.00 × 67.00 |
| **Material & Appearance** | |
| Material | ABS_Plastic |
| Appearance | Paint_Metallic_Dark_Grey |
| Color (RGB 0-1) | (0.349, 0.349, 0.349) |
| Color (RGB 0-255) | (89, 89, 89) |

#### 🔧 COMPONENT: `right_wheel`

| Property | Value |
|----------|-------|
| Full path | `right_wheel:1` |
| Component name | right_wheel |
| Depth | 0 |
| Path segments | right_wheel |
| **Transforms** | |
| Global position (m) | (-0.076000, -0.000000, 0.024750) |
| Global position (mm) | (-76.00, -0.00, 24.75) |
| Local transform (m) | (-0.076000, -0.000000, 0.024750) |
| Assembly context depth | 0 |
| transform2 (m) | (-0.076000, -0.000000, 0.024750) |
| **Physical** | |
| Mass | 0.052668 kg (52.668 g) |
| Volume | 4.968665e-05 m³ |
| Density | 1060.0 kg/m³ |
| Surface area | 2.029151e-02 m² |
| Body count | 1 |
| CoM (component-local, m) | (0.014869, 0.000000, 0.000000) |
| CoM (global, m) | (-0.061131, 0.000000, 0.024750) |
| CoM (global, mm) | (-61.13, 0.00, 24.75) |
| **Inertia at origin (kg·m²)** | |
| Ixx, Iyy, Izz | 3.510455e-05, 3.143996e-05, 3.144021e-05 |
| Ixy, Ixz, Iyz | -1.674041e-10, -7.693060e-11, -1.396434e-10 |
| **Inertia at CoM (kg·m²)** | |
| Ixx, Iyy, Izz | 3.510455e-05, 1.979552e-05, 1.979577e-05 |
| Ixy, Ixz, Iyz | 1.669663e-11, 4.693486e-11, -1.396415e-10 |
| Bounding box (m) | 0.0260 × 0.0670 × 0.0670 |
| Bounding box (mm) | 26.00 × 67.00 × 67.00 |
| **Material & Appearance** | |
| Material | ABS_Plastic |
| Appearance | Paint_Metallic_Dark_Grey |
| Color (RGB 0-1) | (0.349, 0.349, 0.349) |
| Color (RGB 0-255) | (89, 89, 89) |

## Joints

#### ⚡ Joint: `Revolute_5` (as_built)

| Property | Value |
|----------|-------|
| Defining component | sh_order_bot_for_ros (sh_order_bot_for_ros v1) |
| Suppressed | False |
| Motion type | revolute (enum=1) |
| Axis | (-1.0000, 0.0000, 0.0000) |
| **Connections** | |
| Parent (occ2) | `base_link` |
| Parent path | `base_link:1` |
| Child (occ1) | `left_wheel` |
| Child path | `left_wheel:1` |
| **Geometry (all sources, raw cm)** | |
| geometry.origin | (9.8758, -0.0000, 2.4750) |
| occ1.transform | (7.6000, -0.0000, 2.4750) ctx_depth=0 |
| occ1.global (assembled) | (7.6000, -0.0000, 2.4750) |
| occ2.transform | (0.0000, 0.0000, 0.0000) ctx_depth=0 |
| occ2.global (assembled) | (0.0000, 0.0000, 0.0000) |
| **Picked origin (m)** | (0.098758, -0.000000, 0.024750) via `geometry.origin` |

#### ⚡ Joint: `Revolute_6` (as_built)

| Property | Value |
|----------|-------|
| Defining component | sh_order_bot_for_ros (sh_order_bot_for_ros v1) |
| Suppressed | False |
| Motion type | revolute (enum=1) |
| Axis | (-1.0000, 0.0000, 0.0000) |
| **Connections** | |
| Parent (occ2) | `base_link` |
| Parent path | `base_link:1` |
| Child (occ1) | `right_wheel` |
| Child path | `right_wheel:1` |
| **Geometry (all sources, raw cm)** | |
| geometry.origin | (-9.8758, -0.0000, 2.4750) |
| occ1.transform | (-7.6000, -0.0000, 2.4750) ctx_depth=0 |
| occ1.global (assembled) | (-7.6000, -0.0000, 2.4750) |
| occ2.transform | (0.0000, 0.0000, 0.0000) ctx_depth=0 |
| occ2.global (assembled) | (0.0000, 0.0000, 0.0000) |
| **Picked origin (m)** | (-0.098758, -0.000000, 0.024750) via `geometry.origin` |

#### 🔧 Joint: `Rigid_1` (regular)

| Property | Value |
|----------|-------|
| Defining component | base_link (base_link) |
| Suppressed | False |
| Motion type | rigid (enum=0) |
| Axis | (0.0000, 0.0000, 1.0000) |
| **Connections** | |
| Parent (occ2) | `base_link` |
| Parent path | `base_link:1` |
| Child (occ1) | `base_link` |
| Child path | `base_link:1` |
| **Geometry (all sources, raw cm)** | |
| occ1.transform | (0.0000, 0.0000, 0.0000) ctx_depth=0 |
| occ1.global (assembled) | (0.0000, 0.0000, 0.0000) |
| occ2.transform | (0.0000, 0.0000, 0.0000) ctx_depth=0 |
| occ2.global (assembled) | (0.0000, 0.0000, 0.0000) |
| **Picked origin (m)** | (0.000000, 0.000000, 0.000000) via `occ_one_transform2` |

## Quick Comparison Table

Compare these values with Fusion 360 Properties panel (right-click → Properties).

| Component | Mass (g) | World X,Y,Z (mm) | CoM X,Y,Z (mm) | Material |
|-----------|----------|-------------------|-----------------|----------|
| base_link | 924.900 | (0.00, 0.00, 0.00) | (0.00, 1.96, 93.38) | ABS_Plastic |
| left_wheel | 52.668 | (76.00, -0.00, 24.75) | (90.87, -0.00, 24.75) | ABS_Plastic |
| right_wheel | 52.668 | (-76.00, -0.00, 24.75) | (-61.13, 0.00, 24.75) | ABS_Plastic |

## Joint Origins Comparison

All origins shown in multiple coordinate systems for debugging.

| Joint | Source | Origin (cm, raw) | Origin (m, picked) | Motion | Axis |
|-------|--------|------------------|-------------------|--------|------|
| Revolute_5 | geometry.origin | geo(9.88, -0.00, 2.47) | (0.0988, -0.0000, 0.0247) | revolute | (-1.0, 0.0, 0.0) |
| Revolute_6 | geometry.origin | geo(-9.88, -0.00, 2.47) | (-0.0988, -0.0000, 0.0247) | revolute | (-1.0, 0.0, 0.0) |
| Rigid_1 | occ_one_transform2 | ctx(0.00, 0.00, 0.00) | (0.0000, 0.0000, 0.0000) | rigid | (0.0, 0.0, 1.0) |
