# Validation Report: sh_order_bot_for_ros

## Status: PASS

## Summary

| Metric | Value |
|--------|-------|
| Links | 3 |
| Joints | 2 |
| Assemblies | 1 |
| Root | `base_link` |
| Errors | 0 |
| Warnings | 0 |

## Kinematic Tree

```
base_link [primitive]
  └─ Revolute_5 [continuous]
    left_wheel [BAKE] [primitive]
  └─ Revolute_6 [continuous]
    right_wheel [BAKE] [primitive]
```

## Collision Geometry

| Link | Source | Shape/File |
|------|--------|------------|
| `base_link` | primitive STL | cylinder |
| `left_wheel` | primitive STL | cylinder |
| `right_wheel` | primitive STL | cylinder |

## Mesh Bake Offsets

Links where joint frame ≠ component origin. Visual/inertial/collision origins shifted.

| Link | Offset (mm) |
|------|-------------|
| `left_wheel` | (0.0, 0.0, 22.8) |
| `right_wheel` | (0.0, 0.0, -22.8) |
