# Export Log: sh_order_bot_for_ros v1

**Generated:** 2026-10-25T21:32:00.247011

```
[21:31:46] fusion2URDF v3.1.1
[21:31:46] Time: 2026-10-25T21:31:46.565132
[21:31:46] Design: sh_order_bot_for_ros v1
[21:31:46] Components: 4
[21:31:46] 
=== PHASE 1: EXTRACTION ===
[21:31:46]   Document unit: mm
[21:31:46] 
=== EXTRACTION: OCCURRENCES ===
[21:31:46]   [LEAF] d=0 base_link
[21:31:46]     path: base_link:1
[21:31:46]     global_pos: (0.000000, 0.000000, 0.000000) m
[21:31:46]     mass: 0.924900 kg, bodies: 1
[21:31:46]     com_global: (0.000000, 0.001963, 0.093378) m
[21:31:46]     com_component_local: (0.000000, 0.001963, 0.093378) m
[21:31:46]     inertia@origin: ixx=1.225114e-02 iyy=1.225841e-02 izz=1.943558e-03 kg·m²
[21:31:46]     inertia@com:    ixx=4.182968e-03 iyy=4.193801e-03 izz=1.939995e-03 kg·m²
[21:31:46]     material: ABS_Plastic
[21:31:46]     color: RGB(0.15, 0.67, 0.95) [Paint_Metallic_Blue]
[21:31:46]     bbox: (0.1737 x 0.1450 x 0.2042) m
[21:31:46]   [LEAF] d=0 left_wheel
[21:31:46]     path: left_wheel:1
[21:31:46]     global_pos: (0.076000, -0.000000, 0.024750) m
[21:31:46]     mass: 0.052668 kg, bodies: 1
[21:31:46]     com_global: (0.090869, -0.000000, 0.024750) m
[21:31:46]     com_component_local: (0.014869, -0.000000, -0.000000) m
[21:31:46]     inertia@origin: ixx=3.510455e-05 iyy=3.143996e-05 izz=3.144021e-05 kg·m²
[21:31:46]     inertia@com:    ixx=3.510455e-05 iyy=1.979552e-05 izz=1.979577e-05 kg·m²
[21:31:46]     material: ABS_Plastic
[21:31:46]     color: RGB(0.35, 0.35, 0.35) [Paint_Metallic_Dark_Grey]
[21:31:46]     bbox: (0.0260 x 0.0670 x 0.0670) m
[21:31:46]   [LEAF] d=0 right_wheel
[21:31:46]     path: right_wheel:1
[21:31:46]     global_pos: (-0.076000, -0.000000, 0.024750) m
[21:31:46]     mass: 0.052668 kg, bodies: 1
[21:31:46]     com_global: (-0.061131, 0.000000, 0.024750) m
[21:31:46]     com_component_local: (0.014869, 0.000000, 0.000000) m
[21:31:46]     inertia@origin: ixx=3.510455e-05 iyy=3.143996e-05 izz=3.144021e-05 kg·m²
[21:31:46]     inertia@com:    ixx=3.510455e-05 iyy=1.979552e-05 izz=1.979577e-05 kg·m²
[21:31:46]     material: ABS_Plastic
[21:31:46]     color: RGB(0.35, 0.35, 0.35) [Paint_Metallic_Dark_Grey]
[21:31:46]     bbox: (0.0260 x 0.0670 x 0.0670) m
[21:31:46]   Extracted 3 occurrences
[21:31:46] 
=== EXTRACTION: JOINTS ===
[21:31:46]   WARNING:   as_built joint in component 'sh_order_bot_for_ros v1': failed to read occurrenceOne: 2 : InternalValidationError : occPath1.valid()
[21:31:46]   WARNING:   Skipping as_built joint in component 'sh_order_bot_for_ros v1' 'Rigid 2': missing/unreadable endpoint (occurrenceOne=False, occurrenceTwo=True)
[21:31:46]   WARNING:   as_built joint in component 'sh_order_bot_for_ros v1': failed to read geometryOrOriginOne: 'AsBuiltJoint' object has no attribute 'geometryOrOriginOne'
[21:31:46]   WARNING:   as_built joint in component 'sh_order_bot_for_ros v1': failed to read geometryOrOriginTwo: 'AsBuiltJoint' object has no attribute 'geometryOrOriginTwo'
[21:31:46]   [AS_BUILT in sh_order_bot_for_ros] Revolute_5
[21:31:46]     parent(occ2): base_link path=base_link:1
[21:31:46]     child(occ1):  left_wheel path=left_wheel:1
[21:31:46]     geometry.origin: (9.8758, -0.0000, 2.4750) cm
[21:31:46]     occ1.transform: (7.6000, -0.0000, 2.4750) cm (ctx_depth=0)
[21:31:46]     occ1.global:    (7.6000, -0.0000, 2.4750) cm
[21:31:46]     occ2.transform: (0.0000, 0.0000, 0.0000) cm (ctx_depth=0)
[21:31:46]     occ2.global:    (0.0000, 0.0000, 0.0000) cm
[21:31:46]  -> origin_global: (0.098758, -0.000000, 0.024750) m [via geometry.origin]
[21:31:46]     motion: revolute, axis: (-1.000, 0.000, 0.000)
[21:31:46]   WARNING:   as_built joint in component 'sh_order_bot_for_ros v1': failed to read geometryOrOriginOne: 'AsBuiltJoint' object has no attribute 'geometryOrOriginOne'
[21:31:46]   WARNING:   as_built joint in component 'sh_order_bot_for_ros v1': failed to read geometryOrOriginTwo: 'AsBuiltJoint' object has no attribute 'geometryOrOriginTwo'
[21:31:46]   [AS_BUILT in sh_order_bot_for_ros] Revolute_6
[21:31:46]     parent(occ2): base_link path=base_link:1
[21:31:46]     child(occ1):  right_wheel path=right_wheel:1
[21:31:46]     geometry.origin: (-9.8758, -0.0000, 2.4750) cm
[21:31:46]     occ1.transform: (-7.6000, -0.0000, 2.4750) cm (ctx_depth=0)
[21:31:46]     occ1.global:    (-7.6000, -0.0000, 2.4750) cm
[21:31:46]     occ2.transform: (0.0000, 0.0000, 0.0000) cm (ctx_depth=0)
[21:31:46]     occ2.global:    (0.0000, 0.0000, 0.0000) cm
[21:31:46]  -> origin_global: (-0.098758, -0.000000, 0.024750) m [via geometry.origin]
[21:31:46]     motion: revolute, axis: (-1.000, 0.000, 0.000)
[21:31:46]   WARNING:   Skipping regular joint in component 'sh_order_bot_for_ros v1' 'Rigid 1': missing/unreadable endpoint (occurrenceOne=False, occurrenceTwo=True)
[21:31:46]   WARNING:   Skipping regular joint in component 'sh_order_bot_for_ros v1' 'Rigid 3': missing/unreadable endpoint (occurrenceOne=False, occurrenceTwo=True)
[21:31:46]   WARNING:   Skipping regular joint in component 'sh_order_bot_for_ros v1' 'Rigid 4': missing/unreadable endpoint (occurrenceOne=False, occurrenceTwo=True)
[21:31:46]  regular joint in component 'base_link': proxied joint into assembly context 'base_link:1' for geometry origin
[21:31:46]   WARNING:   regular joint in component 'base_link': failed to read geometry: 'Joint' object has no attribute 'geometry'
[21:31:46]   WARNING:   regular joint in component 'base_link': failed to read geometryOrOriginOne: 2 : InternalValidationError : targetObj
[21:31:46]   WARNING:   regular joint in component 'base_link': failed to read geometryOrOriginTwo: 2 : InternalValidationError : targetObj
[21:31:46]   WARNING:   regular joint in component 'base_link': failed to read geometry: 'Joint' object has no attribute 'geometry'
[21:31:46]   WARNING:   regular joint in component 'base_link': failed to read geometryOrOriginOne: 2 : InternalValidationError : targetObj
[21:31:46]   WARNING:   regular joint in component 'base_link': failed to read geometryOrOriginTwo: 2 : InternalValidationError : targetObj
[21:31:46]   [REGULAR in base_link] Rigid_1
[21:31:46]     parent(occ2): base_link path=base_link:1
[21:31:46]     child(occ1):  base_link path=base_link:1
[21:31:46]     occ1.transform: (0.0000, 0.0000, 0.0000) cm (ctx_depth=0)
[21:31:46]     occ1.global:    (0.0000, 0.0000, 0.0000) cm
[21:31:46]     occ2.transform: (0.0000, 0.0000, 0.0000) cm (ctx_depth=0)
[21:31:46]     occ2.global:    (0.0000, 0.0000, 0.0000) cm
[21:31:46]  -> origin_global: (0.000000, 0.000000, 0.000000) m [via occ_one_transform2]
[21:31:46]     motion: rigid, axis: (0.000, 0.000, 1.000)
[21:31:46]   Extracted 3 unique joints
[21:31:46]   WARNING:   Skipped 4 joint(s) that Fusion reported as invalid or unreadable
[21:31:46] 
=== EXTRACTION: RIGID GROUPS ===
[21:31:46]   No rigid groups found
[21:31:46] 
=== EXTRACTION SUMMARY ===
[21:31:46]   Occurrences: 3 (0 subassemblies, 3 leaf components)
[21:31:46]   Joints: 3 (2 as-built, 1 regular)
[21:31:46]   Max nesting depth: 0
[21:31:50] 
=== PHASE 1: DEBUG DATA ===
[21:31:50]   extraction_report.md
[21:31:50]   snapshot.json
[21:31:50]   fusion_transforms.json
[21:31:50] 
=== PHASE 2: BUILD ROBOT MODEL ===
[21:31:50] 
=== MODEL: ASSEMBLY HIERARCHY ===
[21:31:50]   Assembly: sh_order_bot_for_ros (synthetic root, wraps design-root leaves so phase 2 has a macro to xacro:include)
[21:31:50]   base_link → sh_order_bot_for_ros
[21:31:50]   left_wheel → sh_order_bot_for_ros
[21:31:50]   right_wheel → sh_order_bot_for_ros
[21:31:50] 
=== MODEL: RIGID GROUP MERGE ===
[21:31:50]   No explicit rigid groups to merge
[21:31:50]   No auto rigid islands found
[21:31:50]   No rigid groups or auto rigid islands produced merged links
[21:31:50] 
=== MODEL: RESOLVE JOINT PATHS ===
[21:31:50]   Revolute_5           sh_order_bot_for_ros/base_link → sh_order_bot_for_ros/left_wheel  [revolute] internal
[21:31:50]   Revolute_6           sh_order_bot_for_ros/base_link → sh_order_bot_for_ros/right_wheel  [revolute] internal
[21:31:50]   Rigid_1: internal rigid joint inside rigid group sh_order_bot_for_ros/base_link; dropped as redundant
[21:31:50] 
=== MODEL: DETECT ROOT ===
[21:31:50]   Parent-only nodes: 1
[21:31:50]     sh_order_bot_for_ros/base_link
[21:31:50]   → Root: sh_order_bot_for_ros/base_link
[21:31:50] 
=== MODEL: RESOLVE NAMES ===
[21:31:50]   base_link (sh_order_bot_for_ros) → base_link
[21:31:50]   left_wheel (sh_order_bot_for_ros) → left_wheel
[21:31:50]   right_wheel (sh_order_bot_for_ros) → right_wheel
[21:31:50]   Root link URDF name: base_link
[21:31:50] 
=== MODEL: BUILD LINKS ===
[21:31:50]   Built 3 links
[21:31:50] 
=== MODEL: BUILD JOINTS ===
[21:31:50]   NOTE: joint origin rpy derived from child occurrence's transform2 rotation (was hardcoded 0,0,0 pre-2026-04-13)
[21:31:50]   Revolute_5: mesh bake offset = (-22.76, 0.00, -0.00) mm [child-local frame]
[21:31:50]   Revolute_5: joint origin rpy = (3.141593, -0.000000, 0.000000) rad (+180.00°, -0.00°, +0.00°) [from child transform2 rotation]
[21:31:50]   Revolute_5: base_link → left_wheel [continuous]
[21:31:50]     origin_xyz: (0.098758, -0.000000, 0.024750) m [joint_minus_parent]
[21:31:50]     origin_global: (0.098758, -0.000000, 0.024750) m
[21:31:50]   Revolute_6: mesh bake offset = (-22.76, 0.00, 0.00) mm [child-local frame]
[21:31:50]   Revolute_6: joint origin rpy = (0.000000, -0.000000, 3.141593) rad (+0.00°, -0.00°, +180.00°) [from child transform2 rotation]
[21:31:50]  Revolute_6: axis remapped world -> joint/child frame: (-1.000, 0.000, 0.000) -> (1.000, 0.000, 0.000)
[21:31:50]   Revolute_6: base_link → right_wheel [continuous]
[21:31:50]     origin_xyz: (-0.098758, -0.000000, 0.024750) m [joint_minus_parent]
[21:31:50]     origin_global: (-0.098758, -0.000000, 0.024750) m
[21:31:50]   Built 2 joints
[21:31:50] 
=== MODEL: VALIDATE ===
[21:31:50]   Validation passed (0 warnings)
[21:31:50] 
[21:31:50] Kinematic tree:
[21:31:50]   base_link (925g)
[21:31:50]     ─⟳─ Revolute_5 [continuous]
[21:31:50]       left_wheel (53g)
[21:31:50]     ─⟳─ Revolute_6 [continuous]
[21:31:50]       right_wheel (53g)
[21:31:50] 
=== MODEL SUMMARY ===
[21:31:50]   Robot: sh_order_bot_for_ros
[21:31:50]   Root link: base_link
[21:31:50]   Links: 3
[21:31:50]   Joints: 2
[21:31:50]   Assemblies: 1
[21:31:50]   Warnings: 0
[21:31:50]   Errors: 0
[21:31:56] 
=== MESH EXPORT ===
[21:31:56]   base_link:
[21:31:57]     OBJ exported (2917548 bytes)
[21:31:58]     MTL preserved from Fusion (multi-material)
[21:31:58]     DAE written → meshes/sh_order_bot_for_ros/base_link.dae (OBJ retained for collision fit)
[21:31:58]   left_wheel:
[21:31:58]     OBJ exported (1501351 bytes)
[21:31:58]     MTL preserved from Fusion (multi-material)
[21:31:58]     DAE written → meshes/sh_order_bot_for_ros/left_wheel.dae (OBJ retained for collision fit)
[21:31:58]   right_wheel:
[21:31:59]     OBJ exported (1502667 bytes)
[21:31:59]     MTL preserved from Fusion (multi-material)
[21:31:59]     DAE written → meshes/sh_order_bot_for_ros/right_wheel.dae (OBJ retained for collision fit)
[21:31:59] 
  Mesh export summary:
[21:31:59]     Visual (OBJ+MTL):              3
[21:31:59]     Collision sub-component (STL):  0
[21:31:59]     Collision body + warning (STL): 0
[21:31:59]     Skipped (no Fusion ref):        0
[21:31:59] 
=== PHASE 3: SCREENSHOT ===
[21:32:00]   → images/robot.png
[21:32:00] 
=== PACKAGE: GENERATE ===
[21:32:00]   Package: sh_order_bot_for_ros_description
[21:32:00]   Output:  C:/Users/unico/KKH/대학교/개인 프로젝트/ksh_외주\sh_order_bot_for_ros_description
[21:32:00] 
=== COLLISION: RESOLVE ===
[21:32:00]   base_link: primitive (cylinder r=79.7 h=204.2 mm)
[21:32:00]   left_wheel: primitive (cylinder r=33.5 h=26.0 mm)
[21:32:00]   right_wheel: primitive (cylinder r=33.5 h=26.0 mm)
[21:32:00] 
  Collision summary:
[21:32:00]     Explicit:        0
[21:32:00]     Primitive (STL): 3
[21:32:00]     Convex hull STL: 0
[21:32:00]     Visual reuse:    0
[21:32:00]     Visual fallback: 0
[21:32:00] 
=== COLLISION: GENERATE STL ===
[21:32:00]   base_link: cylinder -> 96 tris (4.8 KB)
[21:32:00]   left_wheel: cylinder -> 96 tris (4.8 KB)
[21:32:00]   right_wheel: cylinder -> 96 tris (4.8 KB)
[21:32:00] 
  Generated 3 collision STL files
[21:32:00] 
=== PACKAGE: FRAMES ===
[21:32:00]   -> debug/frame_model.json (pre-frame cache)
[21:32:00]   Frame convention: ros
[21:32:00]   Frame overrides:  config/frame_overrides.csv
[21:32:00]   Rebased links:    2/3
[21:32:00] 
=== PACKAGE: XACRO ===
[21:32:00]   → urdf/assemblies/sh_order_bot_for_ros.urdf.xacro
[21:32:00]   → urdf/sh_order_bot_for_ros.urdf.xacro
[21:32:00] 
=== PACKAGE: URDF (flat, for validation) ===
[21:32:00]   → urdf/sh_order_bot_for_ros.urdf
[21:32:00] 
=== PACKAGE: ROS2 FILES ===
[21:32:00]   → package.xml
[21:32:00]   → CMakeLists.txt
[21:32:00]   → launch/display.launch.py
[21:32:00]   → rviz/display.rviz
[21:32:00]   → config/joint_state.yaml
[21:32:00]   → config/ros2_controllers.yaml
[21:32:00] 
=== PACKAGE: SUPPLEMENTARY DATA ===
[21:32:00]   → robot_data.yaml
[21:32:00]   -> docs/transforms.md
[21:32:00] 
=== PACKAGE: README ===
[21:32:00]   → README.md
[21:32:00]   Cleaned up 6 retained OBJ/MTL files
[21:32:00] 
=== PACKAGE: COMPLETE ===
[21:32:00]   Package generated: C:/Users/unico/KKH/대학교/개인 프로젝트/ksh_외주\sh_order_bot_for_ros_description
[21:32:00]   Xacro: urdf/sh_order_bot_for_ros.urdf.xacro (+ 1 assembly macros)
[21:32:00]   URDF:  urdf/sh_order_bot_for_ros.urdf (flat, for validation)
[21:32:00]   Launch: ros2 launch sh_order_bot_for_ros_description display.launch.py
[21:32:00] 
=== EXPORT COMPLETE ===
```
